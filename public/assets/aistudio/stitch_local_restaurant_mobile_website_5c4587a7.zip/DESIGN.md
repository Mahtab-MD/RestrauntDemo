---
name: Dakhni Clay & Brass
colors:
  surface: '#fff8f6'
  surface-dim: '#e0d8d6'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2f0'
  surface-container: '#f4ecea'
  surface-container-high: '#eee7e4'
  surface-container-highest: '#e8e1df'
  on-surface: '#1e1b1a'
  on-surface-variant: '#58423d'
  inverse-surface: '#33302e'
  inverse-on-surface: '#f7efed'
  outline: '#8b716c'
  outline-variant: '#dfc0b9'
  surface-tint: '#a73923'
  primary: '#88230f'
  on-primary: '#ffffff'
  primary-container: '#a93a24'
  on-primary-container: '#ffd0c6'
  inverse-primary: '#ffb4a4'
  secondary: '#855400'
  on-secondary: '#ffffff'
  secondary-container: '#fdaa31'
  on-secondary-container: '#6b4200'
  tertiary: '#175232'
  on-tertiary: '#ffffff'
  tertiary-container: '#326b48'
  on-tertiary-container: '#ace9be'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a4'
  on-primary-fixed: '#3e0500'
  on-primary-fixed-variant: '#86210e'
  secondary-fixed: '#ffddb7'
  secondary-fixed-dim: '#ffb95d'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#b3f1c5'
  tertiary-fixed-dim: '#98d4aa'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#155131'
  background: '#fff8f6'
  on-background: '#1e1b1a'
  surface-variant: '#e8e1df'
typography:
  headline-xl:
    fontFamily: Vollkorn
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Vollkorn
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Vollkorn
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Vollkorn
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-md:
    fontFamily: Vollkorn
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Vollkorn
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Outfit
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Outfit
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Outfit
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Oswald
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Oswald
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Oswald
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
  price-display:
    fontFamily: Oswald
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality is evocative, hearty, communal, and steeped in the culinary history of Charminar, Hyderabad. It honors the visceral energy of late-night street tiffin stalls, fragrant dum cauldrons sealed with dough, and heritage Irani cafes. The target audience comprises passionate local food lovers, nighttime street food hunters, and discerning diners who crave authentic Hyderabadi culinary heritage without corporate sterility.

The UI avoids generic delivery-aggregator motifs in favor of an **Authentic Tactile Street Stall** design movement. It balances grounded physical textures—hand-painted stall lettering, press-print receipt paper, and seasoned clay handis—with frictionless mobile-first ordering usability. Surfaces feel warm, dense, and spiced rather than airy or clinical. Contrast is deliberately sharp and high-impact to mimic chalkboards, zinc counters, and sun-dried terracotta, inspiring immediate appetite and nostalgic immersion.

## Colors

The palette is derived directly from the kitchen fires and spices of Old Hyderabad:

- **Primary (`#A93A24` - Terracotta Handi):** A sun-baked red-clay tone used for primary calls-to-action, active selection outlines, and signature badge backings.
- **Secondary (`#E09214` - Toasted Haldi):** A warm, vivid turmeric hue used for spotlight badges, order total highlights, and spicy flavor notes.
- **Tertiary (`#1F5938` - Deep Banana Leaf):** An organic, rich botanical green reserved for Vegetarian classification marks, fresh garnish notifications, and verified house-speciality tags.
- **Neutral (`#211E1D` - Tandoor Charcoal):** A rich, carbon-cast soot neutral grounding all primary typography, high-impact borders, and structural framing.

### Supporting Chromatics & Tonal Surfaces
- **Canvas Base (`#FBF6EE` - Raw Dough / Unbleached Parchment):** The foundational backdrop, providing warm, non-glare readability reminiscent of butter paper.
- **Surface Elevation (`#F2E8D9` - Kulhad Buff):** Used for elevated cards, modal drawers, and nested item containers.
- **Non-Veg Emblem (`#7C1717` - Shahi Gosht Maroon):** The mandatory culinary distinction tone for non-vegetarian items.

## Typography

The typographic hierarchy creates a dramatic, authentic editorial tension between the heritage, artisanal warmth of Vollkorn and the industrial, hyper-condensed clarity of Oswald, stabilized by the approachable modern readability of Outfit.

- **Headlines (Vollkorn):** Imbued with robust, literary serifs that evoke vintage culinary manuals, heritage signage, and rustic menu boards. Used for category headers, dish names, and narrative banners.
- **Body & Descriptions (Outfit):** Highly legible geometric sans-serif that balances modern digital clarity against the rustic theme. Renders ingredient notes, spice levels, and order histories cleanly without cognitive fatigue.
- **Labels, Badges & Prices (Oswald):** Tall, condensed, and architectural. Evokes stamped tin counters, bus tokens, and traditional tiffin price boards. Provides immediate visual anchors for prices, quantity multipliers, and category tags.

## Layout & Spacing

This design system uses a rhythmic layout framework anchored by dense, tactile modules reminiscent of physical brass food trays:

- **Mobile (Phone):** Single-column layout with fixed outer gutters of `1rem`. Prioritizes thumb-reachable bottom sticky cart docks, full-bleed imagery anchored by physical container paddings, and horizontally scrollable tiffin category ribbons.
- **Tablet:** 6-column fluid structure with `1.5rem` gutters and adaptive split views separating the category explorer from live cart calculations.
- **Desktop:** 12-column structured grid (max-width `1280px`) flanked by `4rem` margins. Features a persistent side-rail index for rapid category leaping and dual-column item layouts.

Spacing is calculated on an organic 4px/8px modular rhythm, favoring dense culinary groupings (`space-xs` and `space-sm`) for dish tags and pricing, paired with generous section gaps (`space-xl`) between meal times (Morning Tiffin, Afternoon Dum Biryani, Late Night Chai).

## Elevation & Depth

Visual hierarchy rejects ethereal, frosted, or corporate drop-shadows. Depth is built through **Tactile Layering, Inset Tonal Stepping, and High-Contrast Edge Stamping**:

- **Ground Level (Base Canvas):** Unbleached parchment tone (`#FBF6EE`) serving as the foundational surface.
- **Tray Level (Cards & Modular Bins):** Surface containers (`#F2E8D9`) sit flat atop the canvas, framed by an ultra-crisp `1.5px solid #211E1D` structural perimeter rather than a blurred shadow.
- **Stamped Lift (Elevated Elements & Modals):** Achieved via crisp directional hard-offset shadows (block shadows): `2px 3px 0px #211E1D` for interactive cards and `4px 6px 0px #211E1D` for modal drawers. This delivers an authentic letterpress street-token aesthetic.
- **Dividers & Menu Perforations:** Section dividers feature dashed, slotted, or zigzag border patterns evoking tear-off coupon slips and traditional cotton bill books.

## Shapes

The design system adopts a **Soft (Level 1)** shape grammar. Geometry is structural, firm, and disciplined, avoiding the slippery feel of high-radius pills:

- **Core Radius (`0.25rem` / 4px):** Applied to menu cards, action buttons, image frames, and input fields, mimicking clipped metal tokens, cardboard takeaway containers, and printed slips.
- **Accent Badges & Chits (`rounded-lg` / 8px):** Reserved for dietary indicators, tag badges, and floating bottom sheets.
- **Dietary Symbols:** Pure geometric adherence—sharp, unrounded squares for Veg containment and inverted equilateral triangles for Non-Veg signaling.

## Components

### 1. Buttons
- **Primary ("Order Karlein"):** Filled with Terracotta Handi (`#A93A24`), label in Oswald all-caps, bone text (`#FBF6EE`), framed with a `1.5px solid #211E1D` edge and a `2px 2px 0px #211E1D` hard shadow. Pressed state translates the element `1px` downward, collapsing the offset.
- **Secondary / Add Button ("+ ADD"):** Crisp Kulhad Buff (`#F2E8D9`) surface with high-contrast `#211E1D` label and border. Features inline quantity steppers (`- 1 +`) upon activation in vivid Turmeric Yellow (`#E09214`).

### 2. Dietary Identifiers (Clean Veg / Non-Veg Standard)
- **Vegetarian Mark:** A crisp `14px x 14px` square boundary rendered in `1.5px solid #1F5938`, encasing an inner solid green circle (`6px diameter`) centered precisely on pure white backing.
- **Non-Vegetarian Mark:** A crisp `14px x 14px` square boundary rendered in `1.5px solid #7C1717`, encasing an inner solid maroon equilateral triangle (`7px base`) pointing upward.

### 3. Menu Item Cards
- Horizontal cards for mobile tiffin ordering; vertical masonry for specialty dum pots.
- Built on Kulhad Buff (`#F2E8D9`), enclosed with a `1px solid rgba(33, 30, 29, 0.15)` outline. 
- Top row pairs the dietary mark with the Vollkorn dish headline. Bottom row pins the Oswald price tag directly next to the high-contrast "+ ADD" trigger.

### 4. Price Tags
- Prices are styled exclusively in Oswald using the `price-display` token, preceded by a stylized Indian Rupee (`₹`) symbol in `700` weight. Never muted or reduced in opacity.

### 5. Chips & Category Filters
- Segmented filters styled like vintage brass pantry drawer tokens.
- Inactive: Raw parchment background with `#211E1D` text and dotted lower border.
- Active: Filled with Charcoal Neutral (`#211E1D`), text reversed out in Turmeric Yellow (`#E09214`), offset by a subtle `1px` downward nudge.

### 6. Input Fields & Instructions
- "Special Instructions" (e.g., *Double Khatta*, *Extra Salan*, *No Onions*) set inside unvarnished `#FBF6EE` text areas enclosed with a full `1.5px solid #211E1D` stroke, with label tags styled in Oswald uppercase.

### 7. Textured Menu Dividers
- Section boundaries terminate with an ornamental perforated border motif (`repeating-linear-gradient` with dashed teeth) representing vintage Charminar ration cards and tea stubs.